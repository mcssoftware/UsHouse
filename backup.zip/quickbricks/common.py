from abc import ABC, abstractmethod
import logging
from quickbricks.reader.reader_factory import getqueryRepo
from quickbricks.util.runrow import RunRow, getRunRowSchema, convertToRunRow
from quickbricks.util.config import Config
from quickbricks.util.helper import LoadTypeEnum, MedallionType, clean_string, get_from_dictionary, get_schema
from quickbricks.util.spark_helper import get_dbutils, prepare_spark
from pyspark.sql import functions as f, dataframe, Row
from pyspark.sql.window import Window
import traceback
from datetime import datetime


class Task(ABC):
    """
    This is an abstract class that provides handy interfaces to implement workloads (e.g. jobs or job tasks).
    Create a child from this class and implement the abstract launch method.
    Class provides access to the following useful objects:
    * self.spark is a SparkSession
    * self.dbutils provides access to the DBUtils
    * self.logger provides access to the Spark-compatible logger
    * self.conf provides access to the parsed configuration of the job
    """

    def __init__(self, spark=None, init_conf=None):
        self.spark = prepare_spark(spark)
        self.logger = self._prepare_logger()
        self.dbutils = self.get_dbutils()
        self.conf = Config(spark=self.spark, init_conf=init_conf, logger=self.logger)
        self.conf.log()
    
    def get_dbutils(self):
        utils = get_dbutils(self.spark)
        if not utils:
            self.logger.warn("No DBUtils defined in the runtime")
        else:
            self.logger.info("DBUtils class initialized")

        return utils

    def set_target(self, medallionType: MedallionType) -> str:
        target_schema = self.conf.set_for_medallion(medallionType)
        self.ensureTargetSchema(target_schema)
        return target_schema

    def external_injestion(self, config_df: dataframe = None):
        config_map = self.getPreviousBookmark(self.conf["df"] if config_df is None else config_df)
        result = list(map(self._process_load, config_map))
        rdd = self.spark.sparkContext.parallelize(result)
        logdf = self.spark.createDataFrame(rdd, getRunRowSchema())
        logdf.display()
        logdf.write.mode("append").option("mergeSchema", True).saveAsTable(self.conf.log_tbl)

    def _prepare_logger(self):
        logger = logging.getLogger("core")
        logger.setLevel(logging.INFO)
        return logger
        # log4j_logger = self.spark._jvm.org.apache.log4j  # noqa
        # return log4j_logger.LogManager.getLogger(self.__class__.__name__)

    def ensureTargetSchema(self, target_schema):
        self.spark.sql(f"create database if not exists {target_schema}")

    def _get_secrets(self, key):
        scope = get_from_dictionary(self.conf.settings, "secret_scope")
        return self.dbutils.secrets.get(scope, key)

    def getPreviousBookmark(self, configDF: dataframe):
        if self.spark.catalog.tableExists(self.conf.log_tbl):
            windowSpec = Window.orderBy(f.desc("startTime"))
            join_columns = ["name", "databasetype", "connectionString", "dbschema", "tblname"]
            table = (
                self.spark.table(self.conf.log_tbl)
                .filter("ingestionstatus=True")
                .filter(f"loadtype='{LoadTypeEnum.IncrementalAppend.value}' or loadtype='{LoadTypeEnum.IncrementalUpdate.value}'")
                .withColumn("row_number", f.row_number().over(windowSpec))
            )
            right = (
                table.select(join_columns + ["row_number"])
                .groupBy(join_columns)
                .min("row_number")
                .withColumnRenamed("min(row_number)", "row_number")
            )
            templog = table.join(right, join_columns + ["row_number"]).select(
                join_columns + ["Current_WatermarkTimestamp", "row_number"]
            )
            joindf = (
                configDF.join(
                    templog.select(join_columns + ["Current_WatermarkTimestamp"]), on=join_columns, how="left_outer"
                )
                .select(configDF.columns + ["Current_WatermarkTimestamp"])
                .withColumnRenamed("Current_WatermarkTimestamp", "Previous_WatermarkTimestamp")
            )
            return map(convertToRunRow, joindf.collect())
        else:
            new_df = configDF.withColumn("Previous_WatermarkTimestamp", f.lit(None).cast(f.StringType()))
            return map(convertToRunRow, new_df.collect())

    def getTableName(self, schema, tablename) -> str:
        return f"{clean_string(schema)}.{clean_string(tablename)}"

    def getReaderWriter(self, databasetype:str):
        return getqueryRepo(databasetype, lambda x: self._get_secrets(x))

    def _process_load(self, runrow: RunRow):
        self.spark.sql(f"create database if not exists {runrow.target_schema}")
        startTime = datetime.now()
        try:
            queryrepo = self.getReaderWriter(runrow.databasetype)
            spark_read_options = queryrepo.count_query(runrow)
            self.logger.info(spark_read_options)
            statsdf = self.spark.read.format(spark_read_options["format"]).options(**spark_read_options).load().cache()
            toprow: Row = statsdf.select(f.sum('TBLCNT').alias('TBLCNT')).collect()[0]
            runrow.count = int(toprow.TBLCNT)
            print(f'count: {runrow.count}')
            # reset start time for load
            startTime = datetime.now()
            spark_read_options = queryrepo.load_query(runrow)
            self.logger.info(spark_read_options)
            jdbcDf = self.spark.read.format(spark_read_options["format"]).options(**spark_read_options).load().cache()
            jdbcDf.printSchema()
            runrow.deltacount = jdbcDf.count()
            self.logger.info("Delta result count: {0}".format(runrow.deltacount))

            table_name = self.getTableName(runrow.target_schema, runrow.tblname)

            match runrow.loadtype:
                case "fulload":
                    if runrow.target_location is None:
                        jdbcDf.write.format("delta").mode("overwrite").option("truncate", True).option(
                            "mergeSchema", True
                        ).saveAsTable(table_name)
                    else:
                        jdbcDf.write.format("delta").mode("overwrite").option("truncate", True).option(
                            "mergeSchema", True
                        ).option("path", runrow.target_location + "/" + table_name).saveAsTable(table_name)
                case "incremental_append" | "incremental_update":
                    if runrow.pkcols:
                        primary_columns = [x.strip() for x in runrow.pkcols.split(",")]
                        condition = map(lambda x: "dest.{0} = source.{0}".format(x), primary_columns)
                        lst = list(
                            map(
                                lambda x: "dest.{0}=source{0}".format(x),
                                list(set(jdbcDf.columns) - set(primary_columns)),
                            )
                        )
                        updates = dict(map(lambda i: (lst[i], lst[i + 1]), range(len(lst) - 1)[::2]))
                        jdbcDf = (
                            DeltaTable.forname(table_name)
                            .alias("dest")
                            .merge(dfUpdates.alias("updates"), " and ".join(list(condition)))
                            .whenMatchedUpdate(set=updates)
                            .whenNotMatchedInsert()
                        )
                case _:
                    raise Exception(f"{runrow.loadtype} loadtype not supported")

            runrow.targetcount = self.spark.table(table_name).count()
            jdbcDf.unpersist()

        except Exception as e:
            runrow.errormsg = traceback.format_exc()
            self.logger.error(runrow.errormsg)
            print(runrow.errormsg)
        endTime = datetime.now()
        runrow.startTime = startTime.strftime("%Y-%m-%dT%H:%M:%SZ")
        runrow.endTime = endTime.strftime("%Y-%m-%dT%H:%M:%SZ")
        runrow.durationInMins = (endTime - startTime).total_seconds() / 60
        if runrow.errormsg is None:
            runrow.ingestionStatus = True
        else:
            runrow.ingestionStatus = False

        if runrow.count == runrow.targetcount:
            runrow.validationStatus = True
        else:
            runrow.validationStatus = False
        return runrow

    @abstractmethod
    def launch(self):
        """
        Main method of the job.
        :return:
        """
        pass


# org.mongodb.spark:mongo-spark-connector_2.12:10.2.0