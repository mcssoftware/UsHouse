from dataclasses import dataclass
from quickbricks.reader.df_reader import df_reader
from quickbricks.util.runrow import RunRow


class tdv_df_reader(df_reader):
    def base_options(self, runrow: RunRow):
        config = super().base_options(runrow)
        config.update({"format": "jdbc", "driver": "cs.jdbc.driver.CompositeDriver"})
        return config

    def count_query(self, runrow: RunRow):
        df_options = self.base_options(runrow)
        from_table = f'{(runrow.dbschema +".") if runrow.dbschema else ""}{runrow.tblname}'
        if runrow.sql:
            from_table = f"({runrow.sql}) TBL"
        df_options["query"] = f"select count(*) as TBLCNT from {from_table}"
        if runrow.where_clause:
            df_options["query"] = f"{df_options['query']} where {runrow.where_clause}"
        return df_options

    def load_query(self, runrow: RunRow):
        df_options = self.base_options(runrow)
        if runrow.sql or runrow.where_clause:
            sql = runrow.sql if runrow.sql else f"select * from {runrow.tblname}"
            if runrow.where_clause:
                sql = f"{sql} WHERE {runrow.where_clause}"
            df_options["query"] = sql
        return df_options
