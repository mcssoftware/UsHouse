import json
from quickbricks.reader.df_reader import df_reader
from quickbricks.util.runrow import RunRow


class mongo_df_reader(df_reader):
    def shared_options(self, runrow: RunRow, isRead: bool):
        config = self.base_options(runrow)
        url="mongodb+srv://{0}:{1}@{2}".format(config["user"],config["password"],runrow.connectionString)
        if isRead: 
            options={
                'spark.mongodb.input.uri': url,
                'fetchsize': runrow.fetchsize
            }
        else:
            options={
                'spark.mongodb.output.uri': url,
                'maxBatchSize': 10000
            }
        config = {
            "format": "mongo",
            "database": runrow.source_database,
            "collection": runrow.tblname,
        }
        config.update(options)
        return config

    def count_query(self, runrow: RunRow):
        df_options = self.shared_options(runrow, True)
        pipeline = []
        if runrow.where_clause:
            try:
                where_clause = json.loads(runrow.where_clause)
                if (type(where_clause) is list) and (len(where_clause) > 0):
                    if (len(where_clause) > 1):
                        pipeline.append({"$match": {"$and": where_clause}})
                    else:
                        pipeline.append({"$match": where_clause[0]})
            except Exception as e:
                print("error loading filter")
        pipeline.append({"$count": "TBLCNT"})
        df_options.update({"pipeline": json.dumps(pipeline)})
        return df_options

    def load_query(self, runrow: RunRow):
        df_options = self.shared_options(runrow, True)
        return df_options
    
    def write_options(self, runrow: RunRow):
        df_options = self.shared_options(runrow, False)
        return df_options
