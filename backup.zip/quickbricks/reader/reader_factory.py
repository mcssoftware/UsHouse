from quickbricks.reader.mongo_df_reader import mongo_df_reader
from quickbricks.reader.oracle_df_reader import oracle_df_reader
from quickbricks.reader.sql_server_reader import sql_server_reader
from quickbricks.reader.tdv_df_reader import tdv_df_reader


def getqueryRepo(databasetype: str, getsecret):
    match databasetype.lower():
        case "tibcotdv":
            return tdv_df_reader(getsecret)
        case "oracle":
            return oracle_df_reader(getsecret)
        case "mongo":
            return mongo_df_reader(getsecret)
        case "sqlserver":
            return sql_server_reader(getsecret)
        case _:
            raise Exception(f" {databasetype.lower} database type not supported")


# def getqueryRepo(databasetype: str, args):
#     reader = _getReader(databasetype, args)
#     return reader
