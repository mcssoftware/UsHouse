from dataclasses import dataclass
from quickbricks.reader.df_reader import df_reader
from quickbricks.util.runrow import RunRow


class sql_server_reader(df_reader):
    def base_options(self, runrow: RunRow):
        config = super().base_options(runrow)
        connection_info = runrow.connectionString.split(":")
        config.update(
            {
                "format": "sqlserver",
                "encrypt": "true",
                "trustServerCertificate": "true",
                "database": runrow.source_database,
                "host": connection_info[0],
                "port": int(connection_info[1]) if len(connection_info) == 2 else 14330,
            }
        )
        config.pop("url")
        return config

    def count_query(self, runrow: RunRow):
        df_options = self.base_options(runrow)
        df_options[
            "query"
        ] = f'select count(*) as TBLCNT from {(runrow.dbschema +".") if runrow.dbschema else ""}{runrow.tblname}'
        if runrow.where_clause:
            df_options["query"] = f"{df_options['query']} where {runrow.where_clause}"
        return df_options

    def load_query(self, runrow: RunRow):
        df_options = self.base_options(runrow)
        if runrow.sql or runrow.where_clause:
            sql = runrow.sql if runrow.sql else f"select * from {runrow.tblname}"
            if runrow.where_clause:
                sql = f"{sql} WHERE {runrow.where_clause}"
            df_options["query"] = sql
        else:
            df_options["dbtable"] = runrow.tblname
        return df_options
