from dataclasses import dataclass
from quickbricks.util.runrow import RunRow

class df_reader:
    def __init__(self, getsecret) -> None:
        self.get_secrets = getsecret

    def base_options(self, runrow: RunRow):
        return {
            'url': runrow.connectionString,
            'user': self.get_secrets(runrow.userNameSecret),
            'password': self.get_secrets(runrow.passwordSecret),
            'fetchsize': runrow.fetchsize
        }

    def count_query(self, runrow: RunRow):
        pass

    def load_query(self, runrow: RunRow):
        pass
