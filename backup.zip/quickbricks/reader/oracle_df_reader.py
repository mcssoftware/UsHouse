from dataclasses import dataclass
from quickbricks.util.runrow import RunRow
from quickbricks.reader.tdv_df_reader import tdv_df_reader

class oracle_df_reader(tdv_df_reader):
    def count_query(self, runrow: RunRow):
        df_options = super().count_query(runrow)
        df_options.update({'driver': 'oracle.jdbc.driver.OracleDriver'})
        return df_options

    def load_query(self, runrow: RunRow):
        df_options = super().load_query(runrow)
        df_options.update({'driver': 'oracle.jdbc.driver.OracleDriver'})
        return df_options
