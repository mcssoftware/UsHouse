from datetime import datetime
import sys
from quickbricks.common import Task
from quickbricks.util.helper import LoadTypeEnum, MedallionType, clean_string, get_from_dictionary
from pyspark.sql import functions as f, Row

from quickbricks.util.runrow import RunRow, convertToRunRow

sys.argv.extend(
    [
        "--conf-file",
        "/Workspace/Repos/sameer.bhandari@pwc.com/quickbricks.ide/conf/tasks/sample_etl_config.yml",
        "--perfyear",
        "2024",
        "--loadtype",
        "unknown",
    ]
)

fact_table_name = "EDW_CATS_FACT"
engagement_table_name = "EDW_ENGAGEMENT_REF"
client_table_name = "EDW_CLIENT_REF"
employee_table_name = "LKP_GFS_EMPLOYEE_ID"
aggregate_table_name="gfs_hours"
invalid_data_table_name="invalid_gfs_hours"

class SampleETLTask(Task):
    def _write_data(self):
        bronze_schema = self.set_target(MedallionType.Bronze)
        calendar_df = self.conf.df.where('name="mongo_calendars"').limit(1)
        self.external_injestion(calendar_df.withColumn("loadtype", f.lit(LoadTypeEnum.FullLoad.value)))
        # (startdate, enddate) = self._get_startend_perf_year(
        #     get_from_dictionary(self.conf.settings, "perfyear"), calendar_df.collect()[0]
        # )
        # self._set_filters(startdate, enddate)
        # # self.external_injestion(self.conf.df.where('name="mongo_gfs"'))
        # self.external_injestion(self.conf.df.where('databasetype="oracle" or name="mongo_gfs"'))
        # self._transform_gfs(bronze_schema)

    def _get_startend_perf_year(self, perfyear: int, calendar_row: Row):
        table_name = f"{clean_string(calendar_row.target_schema)}.{clean_string(calendar_row.tblname)}"
        calendars_df = self.spark.table(table_name)
        if not perfyear:
            perfyear = (
                calendars_df.where(f.col("startDate") < datetime.now().strftime("%Y-%m-%d")).limit(1).collect()[0].year
            )
        else:
            if isinstance(perfyear, str):
                perfyear = int(perfyear)
        self.conf.settings.update({perfyear: perfyear})
        row = calendars_df.where(f"year={perfyear}").limit(1)
        if row.count() == 0:
            raise Exception(f"Unable to find start date for year {perfyear}")
        startdate = row.collect()[0].startDate
        row = calendars_df.where(f"year={perfyear+1}").limit(1)
        if row.count() == 0:
            raise Exception(f"Unable to find end date for year {perfyear+1}")
        enddate = row.collect()[0].startDate
        return (startdate, enddate)

    def _set_filters(self, startdate: datetime, enddate: datetime):
        cat_fact_filter = [
            "CATS_STATUS = 30",
            "CALENDER_DAY BETWEEN TO_DATE('{}','mm-dd-yyyy') AND TO_DATE('{}','mm-dd-yyyy')".format(
                startdate.strftime("%m-%d-%Y"), enddate.strftime("%m-%d-%Y")
            ),
        ]
        self._addFilterToConfig(fact_table_name, "UPD_BATCH_NBR", "int", cat_fact_filter)
        self._addFilterToConfig(employee_table_name, "UPDATE_DATE", "date", ["PARTY_ID IS NOT NULL"])
        self._addFilterToConfig(client_table_name, "UPD_BATCH_NBR", "int", [])
        self._addFilterToConfig(engagement_table_name, "UPD_BATCH_NBR", "int", [])
        self.conf.df = self.conf.df.withColumn(
            "filter",
            f.when(
                f.col("name") == "mongo_gfs", '[{ "performanceYear": ' + str(self.conf.settings.get("perfyear")) + "}]"
            ).otherwise(self.conf.df["filter"]),
        )

    def _getincrementalFilter(self, tablename: str, columnname: str, columntype: str):
        lastupdated = self.spark.sql("select max({}) as max from {}".format(columnname, tablename)).first()["max"]
        if lastupdated:
            if columntype == "int":
                return "{} > {}".format(columnname, lastupdated)
            if columntype == "str":
                return "{} > '{}'".format(columnname, lastupdated)
            if columntype == "date":
                return "{} > TO_DATE('{}', 'mon-dd-yyyy HH24:MI:SS')".format(
                    columnname, lastupdated.strftime("%m-%d-%Y %H:%M:%S")
                )
        return None

    def _addFilterToConfig(self, tablename: str, columnname: str, columntype: str, initialFilter: list):
        if self.conf.settings["loadtype"] != LoadTypeEnum.FullLoad.value:
            incremental_filter = self.getincrementalFilter(tablename, columnname, columntype)
            if incremental_filter:
                initialFilter.append(incremental_filter)
        if len(initialFilter) > 0:
            self.conf.df = self.conf.df.withColumn(
                "filter", f.when(f.col("tblname") == tablename, " and ".join(initialFilter)).otherwise(f.col("filter"))
            )

    def _transform_gfs(self, bronze_schema: str) -> None:
        fact_df = self.spark.table(self.getTableName(bronze_schema, fact_table_name))
        engagement_df = self.spark.table(self.getTableName(bronze_schema, engagement_table_name))
        client_df = self.spark.table(self.getTableName(bronze_schema, client_table_name))
        edw_employee_df = self.spark.table(self.getTableName(bronze_schema, employee_table_name))
        fact_employee_df = fact_df.fillna(0, ["ACTUAL_TIME"]).join(
            edw_employee_df.where(f.col("PARTY_ID").isNotNull())
            .withColumnRenamed("GFS_EMPLOYEE_ID", "EMPLOYEE_NBR")
            .select(["EMPLOYEE_NBR", "PARTY_ID"]),
            on=["EMPLOYEE_NBR"],
            how="inner",
        )
        invalid_hours = (
            fact_employee_df.withColumn(
                "isvalid",
                f.when(f.col("ACTUAL_TIME").cast("decimal").isNotNull(), f.lit(True)).otherwise(False),
            )
            .where(f.col("isvalid") == False)
            .groupBy(["PARTY_ID", "RECEIVING_WBS"])
            .count()
        )
        aggregated = (
            fact_employee_df.join(invalid_hours, on=["PARTY_ID", "RECEIVING_WBS"], how="leftanti")
            .groupBy(["PARTY_ID", "RECEIVING_WBS"])
            .sum("ACTUAL_TIME")
            .withColumnRenamed("sum(ACTUAL_TIME)", "totalHours")
            .withColumnRenamed("RECEIVING_WBS", "wbsCode")
        )

        engagement_df = engagement_df.select(["ENG_CODE", "CLIENT_KEY", "ENG_DESCR"])
        client_df = client_df.select(["CLIENT_KEY", "CLIENT_CODE", "CLIENT_NAME"])
        client_engagement_df = engagement_df.join(client_df, on=["CLIENT_KEY"], how="inner").withColumnRenamed(
            "ENG_CODE", "wbsCode"
        )
        performance_year=self.conf.settings.get('perfyear')
        silver_col = ["partyId", "wbsCode", "projectName", "clientCode", "clientName", "totalHours", "performanceYear"]
        aggregated_result = (
            aggregated.join(client_engagement_df, on=["wbsCode"], how="inner")
            .withColumnRenamed("PARTY_ID", "partyId")
            .withColumnRenamed("ENG_DESCR", "projectName")
            .withColumnRenamed("CLIENT_CODE", "clientCode")
            .withColumnRenamed("CLIENT_NAME", "clientName")
            .withColumn("performanceYear", f.lit(performance_year))
            .select(silver_col)
            .withColumn("isDeleted", f.lit(False))
        )

        mongo_gfs_exists = self.spark.catalog.tableExists(self.getTableName(bronze_schema, "mongo_gfs"))
        if mongo_gfs_exists:
            mongo_gfs = self.spark.table(self.getTableName(bronze_schema, "mongo_gfs"))

        if mongo_gfs_exists:
            silver_result = (
                aggregated_result.join(
                    mongo_gfs.where(f.col("performanceYear") == performance_year)
                    .select("_id", "partyId", "wbsCode", "performanceYear", "createdDate")
                    .withColumnRenamed("performanceYear", "f.performanceYear"),
                    on=["partyId", "wbsCode"],
                    how="outer",
                )
                .select(["_id", "isDeleted"] + silver_col)
                .fillna(True, subset=["isDeleted"])
            )
        else:
            silver_result = aggregated_result.withColumn("createdDate", f.lit(str(datetime.now()))).withColumn(
                "isDeleted", f.lit(False)
            )
        silver_result = silver_result.withColumn("lastUpdatedDate", f.lit(str(datetime.now())))
        silver_schema = self.conf.get_schema(MedallionType.Silver)
        self.ensureTargetSchema(silver_schema)
        silver_result.write.mode("overwrite").option("mergeSchema", True).saveAsTable(self.getTableName(silver_schema, aggregate_table_name))
        invalid_hours.write.mode("overwrite").option("mergeSchema", True).saveAsTable(self.getTableName(silver_schema, invalid_data_table_name))

    def _write_to_mongo(self):
        runrow:RunRow = list(map(convertToRunRow, self.conf.df.where('name="mongo_gfs"').limit(1)))[0]
        mongowriter=self.getReaderWriter(runrow.databasetype)
        mongooptions = mongowriter.write_options(runrow)
        mongooptions.update({ "operationType": 'update', "upsertDocument": True})
        silver_table = self.getTableName(self.conf.get_schema(MedallionType.Silver), aggregate_table_name)
        self.spark.table(silver_table).write.format(mongooptions['format']).options(**mongooptions).mode("append").save()

    def launch(self):
        self.conf.add_system_argument("perfyear", int)
        self.logger.info("Launching sample ETL task")
        self._write_data()
        self.logger.info("Sample ETL task finished!")


# if you're using python_wheel_task, you'll need the entrypoint function to be used in setup.py
def entrypoint():  # pragma: no cover
    task = SampleETLTask()
    task.launch()


# if you're using spark_python_task, you'll need the __main__ block to start the code execution
if __name__ == "__main__":
    entrypoint()
