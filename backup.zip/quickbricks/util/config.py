import sys
from argparse import ArgumentParser
import logging
import pathlib
import yaml
import json
from quickbricks.util.helper import LoadTypeEnum, MedallionType, get_from_dictionary, get_schema
from pyspark.sql import SparkSession, functions as f
from pyspark.sql.dataframe import DataFrame

logger = logging.getLogger("core")
logger.setLevel(logging.INFO)


class Config(object):
    spark: SparkSession
    settings: dict
    df: DataFrame = None
    log_tbl: str = "quickbricks.mppm_table_log"
    logger: logging.Logger

    def __init__(self, spark: SparkSession, init_conf: dict, logger: logging.Logger) -> None:
        self.spark = spark
        self.logger = logger
        if init_conf:
            self.settings = init_conf.settings
            self.df = init_conf.df
        else:
            conf = self._provide_config(self._get_sys_arg("conf-file"))
            self.settings = conf.get("settings")
            self.df = conf.get("df")
            self.add_system_argument("loadtype", str, LoadTypeEnum.FullLoad.value)
            if self.settings["loadtype"] not in [LoadTypeEnum[x].value for x in LoadTypeEnum.__members__.keys()]:
                self.settings.update({"loadtype": LoadTypeEnum.FullLoad.value})
            self.df = self.df.withColumn("loadtype", f.lit(self.settings["loadtype"]))

    def _get_sys_arg(self, name: str, datatype: type = str):
        p = ArgumentParser()
        p.add_argument("--" + name, type=datatype, required=False)
        namespace = p.parse_known_args(sys.argv[1:])[0]
        return namespace.__dict__[name.replace("-", "_")]

    def _provide_config(self, conf_file: str):
        self.logger.info("Reading configuration from --conf-file job option")
        if not conf_file:
            self.logger.info(
                "No conf file was provided, setting configuration to empty dict."
                "Please override configuration in subclass init method"
            )
            return {}
        else:
            self.logger.info(f"Conf file was provided, reading configuration from {conf_file}")
            return self._read_config(conf_file)

    def _read_config(self, conf_file):
        config = self.load_yaml(spark=self.spark, filename=conf_file)
        return config

    def add_system_argument(self, name: str, datatype: type = str, default_value=None):
        value = self._get_sys_arg(name, datatype)
        if value:
            self.settings.update({name: value})
        else:
            self.settings.update({name: default_value})

    def log(self):
        # log parameters
        self.logger.info("Launching job with configuration parameters:")
        for key, item in self.settings.items():
            self.logger.info(f"\t Parameter: {key} ")
            if type(item) is dict:
                for key1, item1 in item.items():
                    self.logger.info("\t Parameter: %-30s with value => %-30s" % (key1, item1))
            # if str(type(item)) == "<class 'pyspark.sql.dataframe.DataFrame'>":
            #     item.show()

    def set_for_medallion(self, medallionType: MedallionType) -> str:
        target_schema = self.get_schema(medallionType)
        targetLocation = get_from_dictionary(self.settings, "target_location")
        self.log_tbl = f"{target_schema}.mppm_table_log"
        self.df = self.df.withColumn("target_schema", f.lit(target_schema)).withColumn(
            "target_location", f.lit(targetLocation)
        )
        return target_schema

    def get_schema(self, medallionType: MedallionType) -> str:
        return get_schema(medallionType, get_from_dictionary(self.settings, "target_schema", "quickbricks"))

    @staticmethod
    def load_yaml(spark, filename: str):
        try:
            config_details = yaml.safe_load(pathlib.Path(filename).read_text())
            logger.info("config file loaded successfully")
            return Config.__process_dict(spark=spark, configJson=config_details)
        except:
            logger.error("config file not found ")

    @staticmethod
    def load_json(spark, filename: str):
        try:
            config_json = json.safe_load(pathlib.Path(filename).read_text())
            logger.info("config file loaded successfully")
            return Config.__process_dict(spark=spark, configJson=config_json)
        except:
            logger.error("config file not found ")

    @staticmethod
    def __process_dict(spark, configJson: dict):
        try:
            rddjson = spark.sparkContext.parallelize([json.dumps(configJson)])
            dfJson = spark.read.option("multiline", "true").json(rddjson)
            explodeddf = (
                dfJson.select(f.explode("connections").alias("connection"))
                .selectExpr("connection.*")
                .select("*", f.explode("tablelist").alias("table"))
                .select("*", "table.*")
                .drop("connection", "table", "tablelist")
            )
            return {"settings": configJson, "df": explodeddf}
        except Exception as inst:
            print(inst)
            logger.error("error while exploding the config")
