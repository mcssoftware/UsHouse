from enum import Enum
import re

class LoadTypeEnum(Enum):
    FullLoad = 'fulload'
    IncrementalAppend = 'incremental_append'
    IncrementalUpdate = 'incremental_update'

class MedallionType(Enum):
    Bronze = 'bronze'
    Silver = 'silver'
    Gold = 'gold'

def clean_string(value:str):
    if value is not None: 
        return re.sub(r'[^a-zA-Z0-9_]', '', value)

def get_from_dictionary(dic:dict, key:str, default=None):
    if dic.get(key) is not None:
        return dic[key]
    else:
        return default

def get_schema(medallion:MedallionType, schema:str) -> str:
    return f'{clean_string(schema)}_{medallion.value} '