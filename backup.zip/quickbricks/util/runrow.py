from dataclasses import dataclass
from datetime import datetime
from pyspark.sql import Row
import re
# from pyspark.sql import dataframe,column,functions as f,Row, types as t


@dataclass
class RunRow:
    name: str
    databasetype: str
    userNameSecret: str
    passwordSecret: str
    connectionString: str
    tblname: str
    loadtype: str
    sql: str
    where_clause: str
    dbschema: str
    source_database: str
    target_location: str
    target_schema: str
    max_connections: str
    jobid: str = None
    partitioncolumn: str = None
    WatermarkTimestamp: str = None
    lowerbound: str = None
    upperbound: str = None
    fetchsize: int = None
    errormsg: str = None
    durationInMins: float = None
    startTime: datetime = None
    endTime: datetime = None
    count: int = None
    targetcount: int = None
    deltacount: int = None
    Previous_WatermarkTimestamp: str = None
    Current_WatermarkTimestamp: str = None
    pkcols: str = None
    validationStatus: bool = None
    ingestionStatus: bool = None

def getProp(prop_type):
    data_type= re.findall("(?:')(.+)'", str(prop_type))[0]
    if data_type == "'str'": return 'string'
    if data_type == "'int'": return 'int'
    if data_type == "'bool'": return 'boolean'
    if data_type == "'float'": return 'float'
    if data_type == "'datetime.datetime'": return 'timestamp'
    return 'string'

def getRunRowSchema():
    annotation = RunRow.__dict__['__annotations__']
    return ','.join([f'{x}:{getProp(y)}' for x,y in annotation.items()])

# print(getRunRowSchema())

def convertToRunRow(row: Row):
    return RunRow(
        name=row.name,
        databasetype=row.databasetype,
        userNameSecret=row.userNameSecret,
        passwordSecret=row.passwordSecret,
        connectionString=row.connectionString,
        tblname=row.tblname,
        loadtype=row.loadtype,
        sql=row.sql,
        where_clause=row.filter,
        dbschema=row.dbschema,
        source_database=row.source_database,
        pkcols=row.pkcols,
        target_location=row.target_location,
        target_schema=row.target_schema,
        max_connections=row.maxconnections,
        fetchsize=100000,
        Previous_WatermarkTimestamp=row.Previous_WatermarkTimestamp,
    )
