import { AzureKeyCredential, SearchClient } from "@azure/search-documents";

const searchConfig = {
  serviceEndpoint: "https://aisearchsrvceprotoeus2001.search.windows.net",
  indexName: "bioguideprofilevector",
  serviceKey: "qgKX91HoanSgBkXTNR44Bs5lsBGQKH6oUMuQLAXE7AAzSeATMXYM",
};

const client = new SearchClient(
  searchConfig.serviceEndpoint,
  searchConfig.indexName,
  new AzureKeyCredential(searchConfig.serviceKey)
);

export const searchEmbeddings = async (inputText) => {
  const data = {
    input: inputText,
  };

  const result = [];

  const searchURL =
    "https://oaiprotoeus2001.openai.azure.com/openai/deployments/text-embedding-ada-002/embeddings?api-version=2024-02-15-preview";
  const headers = {
    "Content-Type": "application/json",
    "api-key": "8f0de5a087974908932b65891839bb3d",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST,PATCH,OPTIONS",
  };

  try {
    const response = await fetch(searchURL, {
      method: "POST",
      headers: headers,
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error("Network response was not ok");
    }

    const embeddingData = await response.json();
    const queryVector = embeddingData.data[0].embedding;

    await search(inputText, queryVector);

    let stringResult = "";
    for (const item of result) {
      stringResult += item.document.chunk;
    }
    return stringResult;
  } catch (error) {
    console.error("Error:", error);
    return [];
  }

  async function search(inputText, queryVector) {
    console.log("query text before search call", inputText);
    const searchResults = await client.search(inputText, {
      vectorQueries: [
        {
            vector: queryVector,
            fields: "embedding",
            kind: "vector",
            k: 1
        }
        ],
      select: ["chunk"],

      // Optional Additional properties to enable Semantic Ranking
      //
      queryType: "semantic",
      semanticConfiguration: "bioguideprofilevector-semantic-configuration",
      // captions: "extractive",
      // answers: "extractive",
      top: 3
    });

    for await (const item of searchResults.results) {
      result.push(item);
      console.log("item", item);
    }
  }
};
