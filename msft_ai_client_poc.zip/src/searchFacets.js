import { AzureKeyCredential, SearchClient } from "@azure/search-documents";

const searchConfig = {
  serviceEndpoint: "https://aisearchsrvceprotoeus2001.search.windows.net",
  indexName: "bioguidefacet2-index",
  serviceKey: "qgKX91HoanSgBkXTNR44Bs5lsBGQKH6oUMuQLAXE7AAzSeATMXYM",
};

// Create a Search Client with endpoint, bioguide facet index and query key
const client = new SearchClient(
  searchConfig.serviceEndpoint,
  searchConfig.indexName,
  new AzureKeyCredential(searchConfig.serviceKey)
);

// Query for top 5 results
const searchFacets = async (inputText) => {
  const searchResults = await client.search(inputText, {
    top: 5,
    skip: 0,
  });

  const results = [];
  for await (const result of searchResults.results) {
    results.push({
      score: result.score,
      document: result.document,
    });
  }

  return { results: results, totalCount: searchResults.count };
};

// Format the results into JSON string that the model can understand.
function formatContext(searchResults) {
  return searchResults.map((object) => JSON.stringify(object)).join("\n");
}

export { searchFacets, formatContext };
