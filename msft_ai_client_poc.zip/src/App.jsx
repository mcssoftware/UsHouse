import { useState } from "react";
import "./ChatApp.css"; // Create a CSS file for styling
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faTrashCan,
  faPaperPlane,
  faBuildingColumns,
} from "@fortawesome/free-solid-svg-icons";
import Markdown from "react-markdown";
import { searchEmbeddings } from "./searchEmbeddings";
// Facet Version
// import { queryIndex, formatContext } from "./ChatHelper";

const ChatApp = () => {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState("");
  const settingsData = {
    apiUrl:
      "https://oaiprotoeus2001.openai.azure.com/openai/deployments/gpt-4o-mini/chat/completions?api-version=2025-01-01-preview",
    apiKey: "8f0de5a087974908932b65891839bb3d",
  };
  // Add a message to display
  const addMessage = (text, role) => {
    const newMessage = { text, role };
    setMessages((prevMessages) => [...prevMessages, newMessage]);
  };

  const handleUserInput = (e) => {
    setInputText(e.target.value);
  };

  // Sends a query first to the search service and then to the Chat model with added context and history.
  const handleSendMessage = async () => {
    if (inputText.trim() === "") return;

    // Use helper function to query the index with input text (returns top 5 results) and then format the results array into a JSON string.
    const context = await searchEmbeddings(inputText);
    // Old version
    // const context = await queryIndex(inputText).then((r) =>
    //   formatContext(r.results)
    // );

    console.log("returned context", context);

    // Grab and stringify the last 3 messages from state to add to the Chat model query
    const history = JSON.stringify(messages.slice(-10));
    console.log("history", history);

    //          \nMy data contains name and value pairs in the format of "name: value".  For example: "familyName: Miller".  When the user provides a name, look for a value within the name's pair that matches the user-supplied value exactly.  The value cannot match any other name's value within the same document.  If the name matches and you do not get an exact value match, reply with "I cannot find that information."  Consider "last name" to be a synonym for the "familyName" name.


    // Construct the Chat model request
    const requestBody = {
      messages: [
        {
          role: "system",
          content: `You are a bioguide expert on US Congressional History. 
          \nAnswer all questions using this information: 
          \n${context} 
          \n-- 
          \nHistory: 
          \n${history}`,
        },
        {
          role: "user",
          content: inputText,
        },
      ],
      max_tokens: 800,
      temperature: 0.7,
      frequency_penalty: 0,
      presence_penalty: 0,
      top_p: 0.95,
      stop: null,
    };

    // Add user message to state and clear input (TODO: autoscroll)
    addMessage(inputText, "user");
    setInputText("");

    try {
      const response = await fetch(settingsData.apiUrl, {
        method: "POST",
        body: JSON.stringify(requestBody),
        headers: {
          "Content-Type": "application/json",
          "api-key": settingsData.apiKey,
        },
      });

      if (!response.ok) {
        throw new Error("Failed to fetch response from the AI assistant");
      }

      const responseData = await response.json();

      // For visibility
      console.log("Response data:", responseData);

      // Extract the assistant's reply from the response
      const assistantReply = responseData.choices[0]?.message.content;

      addMessage(assistantReply, "assistant");
    } catch (error) {
      console.log(error);
      console.error("Error fetching data from the API:", error.message);
      addMessage("Error fetching data from the API", "assistant");
    }
  };

  const handleClearChat = () => {
    setMessages([]);
    console.log("cleared chat history", messages);
  };

  return (
    <div className="container">
      <h2>
        <FontAwesomeIcon icon={faBuildingColumns} /> Bioguide Chat Demo
      </h2>

      <div className="chat-app">
        <div className="chat-window">
          {messages.map((message, index) => (
            <div
              key={index}
              className={
                message.role === "user" ? "user-message" : "assistant-message"
              }
            >
              <Markdown>{message.text}</Markdown>
            </div>
          ))}
        </div>
        <div className="input-container">
          <input
            type="text"
            value={inputText}
            onChange={handleUserInput}
            onKeyDown={(e) => (e.key === "Enter" ? handleSendMessage() : "")}
            placeholder="Type your message..."
          />
          <button onClick={handleSendMessage}>
            <FontAwesomeIcon icon={faPaperPlane} /> Send
          </button>
          <button onClick={handleClearChat}>
            <FontAwesomeIcon icon={faTrashCan} /> Clear
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatApp;
