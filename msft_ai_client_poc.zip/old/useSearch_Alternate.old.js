import { AzureOpenAI } from "openai";
import "@azure/openai/types";

// Your Azure Cognitive Search endpoint, and index name
const azureSearchEndpoint =
  "https://aisearchsrvceprotoeus2001.search.windows.net";
const azureSearchIndexName = "bioguidechatpoc";
const azureSearchKey = "EbAm0qREa4CCSK4Y7EW9TmTNpEyKMiHQUT9iIikViPAzSeB2Vqk1";
// const azureApiKey = "8f0de5a087974908932b65891839bb3d";
const endpoint = "https://oaiprotoeus2001.openai.azure.com";
const deployment = "gpt-4o-mini";
// const apiVersion = "2024-10-21";

export async function chatQuery(query) {
  console.log("== Azure On Your Data Sample ==");

  // const client = new AzureOpenAI({ azureApiKey, deployment, apiVersion, });
  const options = {
    // baseURL: "https://oaiprotoeus2001.openai.azure.com",
    apiKey: "8f0de5a087974908932b65891839bb3d",
    apiVersion: "2024-10-21",
    endpoint,
    deployment,
    // azureADTokenProvider,
    dangerouslyAllowBrowser: true,
    // ...opts
  };
  const client = new AzureOpenAI(options);
  const events = await client.chat.completions.create({
    stream: true,
    messages: [
      {
        role: "user",
        content: query,
      },
    ],
    max_tokens: 800,
    temperature: 0.7,
    frequency_penalty: 0,
    presence_penalty: 0,
    top_p: 0.95,
    model: "",
    data_sources: [
      {
        type: "azure_search",
        parameters: {
          endpoint: azureSearchEndpoint,
          index_name: azureSearchIndexName,
          authentication: {
            type: "api_key",
            key: azureSearchKey,
          },
          strictness: 3,
          top_n_documents: 10
        },
      },
    ],
  });

  let result = '';
  for await (const event of events) {
    for (const choice of event.choices) {
      // console.log("choice", choice)
      result += choice.delta.content;
    }
  }
  console.log("result", result);
  return result;
}

// import { AzureOpenAI } from "openai";
// import { AzureKeyCredential } from "@azure/core-auth";
// import { config } from "dotenv";

// export async function main() {
//   config();
//   const endpoint = process.env["AZURE_OPENAI_ENDPOINT"];
//   const azureApiKey = process.env["AZURE_OPENAI_API_KEY"];
//   const deploymentId = process.env["AZURE_OPENAI_DEPLOYMENT_ID"];
//   const OPENAI_API_VERSION = process.env["AZURE_OPENAI_API_VERSION"];
//   const searchEndpoint = process.env["AZURE_AI_SEARCH_ENDPOINT"];
//   const searchKey = process.env["AZURE_AI_SEARCH_API_KEY"];
//   const searchIndex = process.env["AZURE_AI_SEARCH_INDEX"];

//   if (
//     !endpoint ||
//     !azureApiKey ||
//     !deploymentId ||
//     !searchEndpoint ||
//     !searchKey ||
//     !searchIndex
//   ) {
//     console.error("Please set the required environment variables.");
//     return;
//   }

//   const client = new AzureOpenAI(
//     endpoint,
//     new AzureKeyCredential(azureApiKey),
//     OPENAI_API_VERSION,
//     deploymentId
//   );

//   const messages = [
//     {
//       role: "system",
//       content: "You are an AI assistant that helps people find information.",
//     },
//     { role: "user", content: "Hi How are you?" },
//   ];
//   console.log(`Message: ${messages.map((m) => m.content).join("\n")}`);

//   const events = await client.streamChatCompletions(deploymentId, messages, {
//     pastMessages: 10,
//     maxTokens: 800,
//     temperature: 0.7,
//     topP: 0.95,
//     frequencyPenalty: 0,
//     presencePenalty: 0,

//     azureExtensionOptions: {
//       extensions: [
//         {
//           type: "AzureCognitiveSearch",
//           endpoint: searchEndpoint,
//           key: searchKey,
//           indexName: searchIndex,
//         },
//       ],
//     },
//   });

//   let response = "";
//   for await (const event of events) {
//     for (const choice of event.choices) {
//       const newText = choice.delta?.content;
//       if (!!newText) {
//         response += newText;
//         // To see streaming results as they arrive, uncomment line below
//         // console.log(newText);
//       }
//     }
//   }
//   console.log(response);
// }

// main().catch((err) => {
//   console.error("The sample encountered an error:", err);
// });
