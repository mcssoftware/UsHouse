// Initialize the conversation history object
let conversationHistory = {};
 
// Function to capture user prompt and AI response
function captureConversation(userPrompt, aiResponse) {
    conversationHistory[userPrompt] = aiResponse;
}
 
// Example usage
let userPrompt = "Hello, how are you?";
let aiResponse = "I'm doing great, thank you! How can I assist you today?";
 
captureConversation(userPrompt, aiResponse);
 
// Convert object to string format
let conversationString = JSON.stringify(conversationHistory);
 
console.log(conversationString);