import { useState } from "react";
import "./ChatApp.css"; // Create a CSS file for styling
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCog,
  faTrashCan,
  faPaperPlane,
  faBuildingColumns,
} from "@fortawesome/free-solid-svg-icons";
import { AzureKeyCredential, SearchClient } from "@azure/search-documents";
import Markdown from "react-markdown";

const ChatApp = () => {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const [settingsData, setSettingsData] = useState({
    apiUrl:
      "https://oaiprotoeus2001.openai.azure.com/openai/deployments/gpt-4o-mini/chat/completions?api-version=2025-01-01-preview",
    apiKey: "8f0de5a087974908932b65891839bb3d",
  });

  const serviceEndpoint =
    "https://aisearchsrvceprotoeus2001.search.windows.net";
  const indexName = "bioguidefacet2-index";
  const serviceKey = "qgKX91HoanSgBkXTNR44Bs5lsBGQKH6oUMuQLAXE7AAzSeATMXYM";

  const addMessage = (text, role) => {
    const newMessage = { text, role };
    setMessages((prevMessages) => [...prevMessages, newMessage]);
  };

  const handleUserInput = (e) => {
    setInputText(e.target.value);
  };

  const client = new SearchClient(
    serviceEndpoint,
    indexName,
    new AzureKeyCredential(serviceKey)
  );
  const queryIndex = async (inputText, top = 5, skip = 0) => {
    const searchResults = await client.search(inputText, {
      top: top,
      skip: skip,
      // select: ['document'],
      includeTotalCount: true,
    });
    console.log("initial search results", searchResults);
    const results = [];
    // for await (const result of searchResults.results) {
    //   results.push(result.document)
    // }
    for await (const result of searchResults.results) {
      results.push({
        score: result.score,
        document: result.document,
      });
    }
    console.log("results", results);
    return { results: results, totalCount: searchResults.count };
  };

  function formatContext(searchResults) {
    // return searchResults.map(result => result.document.content).join('\n')
    // return JSON.stringify(searchResults.map(result => result.document.content).join('\n'))
    return searchResults.map((object) => JSON.stringify(object)).join("\n");
  }
  const handleSendMessage = async () => {
    if (inputText.trim() === "") return;

    const context = await queryIndex(inputText).then((r) =>
      formatContext(r.results)
    );

    console.log("context", context);

    // Prepare the request payload based on the curl command
    const requestBody = {
      messages: [
        {
          role: "system",
          content:
            "You are an AI assistant that helps people find information.",
        },
        { role: "user", content: context + "\n\n" + inputText },
      ],
      max_tokens: 800,
      temperature: 0.7,
      frequency_penalty: 0,
      presence_penalty: 0,
      top_p: 0.95,
      stop: null,
    };

    addMessage(inputText, "user");
    setInputText("");

    try {
      const response = await fetch(settingsData.apiUrl, {
        method: "POST",
        body: JSON.stringify(requestBody),
        headers: {
          "Content-Type": "application/json",
          "api-key": settingsData.apiKey,
        },
      });

      if (!response.ok) {
        throw new Error("Failed to fetch response from the AI assistant");
      }

      const responseData = await response.json();
      console.log("Response data:", responseData);
      const assistantReply = responseData.choices[0]?.message.content; // Extract the assistant's reply from the response

      addMessage(assistantReply, "assistant");
    } catch (error) {
      console.log(error);
      console.error("Error fetching data from the API:", error.message);
      addMessage("Error fetching data from the API", "assistant");
    }
  };

  const handleClearChat = () => {
    setMessages([]);
  };

  const handleSettingsClick = () => {
    setShowSettings(true);
  };

  const handleSettingsClose = () => {
    setShowSettings(false);
  };

  const handleSaveSettings = () => {
    // You may want to add validation logic here before saving the settings
    setSettingsData({
      apiUrl: settingsData.apiUrl,
      apiKey: settingsData.apiKey,
    });
    setShowSettings(false);
  };

  return (
    <div className="container">
      <h2>
        <FontAwesomeIcon icon={faBuildingColumns} /> Bioguide Chat Demo
      </h2>
      {/* new code */}

      {showSettings && (
        <div className="settings-popup">
          <div className="settings-content">
            <label htmlFor="apiUrl">API URL:</label>
            <input
              type="text"
              id="apiUrl"
              value={settingsData.apiUrl}
              onChange={(e) =>
                setSettingsData({ ...settingsData, apiUrl: e.target.value })
              }
            />

            <label htmlFor="apiKey">API Key:</label>
            <input
              type="text"
              id="apiKey"
              value={settingsData.apiKey}
              onChange={(e) =>
                setSettingsData({ ...settingsData, apiKey: e.target.value })
              }
            />

            <button onClick={handleSaveSettings}>Save</button>
            <button onClick={handleSettingsClose}>Cancel</button>
          </div>
        </div>
      )}
      {/* end new code */}

      <div className="chat-app">
        <div className="chat-window">
          {messages.map((message, index) => (
            <div
              key={index}
              className={
                message.role === "user" ? "user-message" : "assistant-message"
              }
            >
              <Markdown>{message.text}</Markdown>
            </div>
          ))}
        </div>
        <div className="input-container">
          <input
            type="text"
            value={inputText}
            onChange={handleUserInput}
            placeholder="Type your message..."
          />
          <button onClick={handleSendMessage}>
            <FontAwesomeIcon icon={faPaperPlane} /> Send
          </button>
          <button onClick={handleClearChat}>
            <FontAwesomeIcon icon={faTrashCan} /> Clear
          </button>
          <button className="settings-button" onClick={handleSettingsClick}>
            <FontAwesomeIcon icon={faCog} /> Settings
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatApp;
