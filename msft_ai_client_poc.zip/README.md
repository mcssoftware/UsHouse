## Getting Started

1. **Install Dependencies:**

   ```
   npm install
   ```

2. **Run the App:**

   ```
   npm run dev
   ```